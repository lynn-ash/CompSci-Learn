const quizData = [
    {
        question: "The programming practice where following a specific series of steps is needed in order for the code to execute properly",
        options: ["Procedural Programming", "Structured Programming", "Assembly Programming", "Object Oriented Programming"],
        answer: "Procedural Programming"
    },
    {
        question: "Contains a set of rules that helps in the connection and exchange of data between computer applications",
        options: ["RDS", "Lambda Function", "Permission Policies", "Application Programming Interface (API)"],
        answer: "Application Programming Interface (API)"
    },
    {
        question: "What is the name of the material that can conduct electricity under certain conditions?",
        options: ["Semiconductor", "Circuit", "Transistor", "Inverter"],
        answer: "Semiconductor"
    },
    {
        question: "The system that manages both hardware and software applications is called what?",
        options: ["Relational Database", "Operating System", "Container", "Bucket"],
        answer: "Operating System"
    },
    {
        question: "Image recognition, Spam filtering, predictive text, and recommendation systems are all possible as a result of what?",
        options: ["Semiconductors", "Artificial Intelligence", "Machine Learning", "DevOps"],
        answer: "Machine Learning"
    },
    
];
 


const questionID = document.getElementById("question");
const optionsID = document.getElementById("options");

//Records the user's name
let userName = prompt("Please enter your first name:");

//Keeps track of the player's score
let score = 0;

//Keeps track of the question being answered.
let currentQuestion = 0;

//Presents the questions onto the screen
function loadQuiz(){
    //Variable that  tracks the current question number
    const question = quizData[currentQuestion];

    //Sets the content of questionID to the actual question text from quizData
    questionID.innerText = question.question;

    //Clears out pre-existing content in optionsID
    optionsID.innerHTML = "";

    //Loops through each option from quizData's option array
    question.options.forEach(option => {
        const opButton = document.createElement("button"); //creates new button for option
        opButton.innerText = option; //options text displayed in the button
        opButton.addEventListener("click", () => chooseAnswer(opButton.innerText)); //calls chooseAnswer() function
        optionsID.appendChild(opButton); //adds button to optionsID so it shows up on the page
    });
}

function chooseAnswer(userChoice){
    //Checks to see if student's choice matches the correct answer
    if(userChoice === quizData[currentQuestion].answer){
        score++; //increments score if the answer is correct

    }
    //Moves onto the next question
    currentQuestion++;

    //Brings up next question if there are more left
    if(currentQuestion < quizData.length){
        loadQuiz();
    }
    else{
        totalScore();
    }
}

//Prints out the student's final score
/**This function will eventually need some more added to it in order
 * to work with the API Gateway
 */
function totalScore(){
    //Will eventually be used to store player information
    const result = {
        name: userName,
        score: score,
        total: quizData.length
    }

    document.querySelector(".quizContainer").innerHTML = `
        <h1>Quiz Completed.</h1>
        <p>Final Score: ${score}/${quizData.length}</p>
    `;
}

loadQuiz();